package com.mahesh.java8.defaultmethods;

public class Test {

	public static void main(String[] args) {

		A a = new B();
		a.m1();

	}

}
