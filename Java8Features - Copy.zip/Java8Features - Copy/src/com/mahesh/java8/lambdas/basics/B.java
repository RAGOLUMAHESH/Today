package com.mahesh.java8.lambdas.basics;


@FunctionalInterface
public interface B extends A {
	
	void myMethod();
}
