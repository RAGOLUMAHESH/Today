package com.mahesh.java8.lambdas;

public class Test {

	public static void main(String[] args) {
		
		A a = () -> System.out.println("hello ");
		
		a.myMethod();

	}

}
