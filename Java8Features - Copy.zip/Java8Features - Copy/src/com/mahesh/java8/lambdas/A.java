package com.mahesh.java8.lambdas;

public interface A {
	
	void myMethod();

}
