package com.mahesh.java8.foreach;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<String> fruits = new ArrayList<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Orange");

        // Using forEach to print each element of the list
        fruits.forEach(fruit -> System.out.println(fruit));
    }
}
