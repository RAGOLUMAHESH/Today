package com.mahesh.java8.predicate;

import java.util.function.BiPredicate;

public class Main {
    public static void main(String[] args) {
        // Define a BiPredicate to check if the sum of two numbers is even
        BiPredicate<Integer, Integer> isSumEven = (a, b) -> (a + b) % 2 == 0;

        // Test the BiPredicate with different pairs of numbers
        System.out.println("Is sum of 2 and 3 even? " + isSumEven.test(2, 3));
        System.out.println("Is sum of 4 and 6 even? " + isSumEven.test(4, 6));
        System.out.println("Is sum of 5 and 9 even? " + isSumEven.test(5, 9));
    }
}
