package com.mahesh.java8.functions;

import java.util.function.BiFunction;

public class Main {
    public static void main(String[] args) {
        // Define a BiFunction to concatenate two strings with a separator
        BiFunction<String, String, String> concatenateFunction = (s1, s2) -> s1 + " | " + s2;

        // Apply the BiFunction to two strings
        String result = concatenateFunction.apply("Hello", "world");

        // Print the result
        System.out.println("Result: " + result);
    }
}
