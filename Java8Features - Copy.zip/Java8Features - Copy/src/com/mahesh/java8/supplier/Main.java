package com.mahesh.java8.supplier;

import java.util.function.Supplier;

public class Main {
    public static void main(String[] args) {
        // Define a Supplier that generates a constant value
        Supplier<String> constantSupplier = () -> "Hello, world!";
        
        // Get the value from the Supplier
        String message = constantSupplier.get();
        
        // Print the value
        System.out.println(message);
    }
}
