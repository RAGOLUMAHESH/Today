package com.mahesh.java8.consumer;

import java.util.function.BiConsumer;

public class test {
    public static void main(String[] args) {
        // Define a BiConsumer to print two integers
    	BiConsumer<Integer, Integer> printNumbers = (a, b) -> System.out.println("First number: " + a + ", Second number: " + b);

        // Use the BiConsumer to print two numbers
        printNumbers.accept(10, 20);
    }
}