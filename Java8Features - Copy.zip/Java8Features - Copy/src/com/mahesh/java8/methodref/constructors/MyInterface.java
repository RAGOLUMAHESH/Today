package com.mahesh.java8.methodref.constructors;

public interface MyInterface {
	
	MyClass get(String s);

}
