package com.mahesh.java8.methodref.constructors;

public class MyClass {
	
	private String s;
	
	MyClass(String s){
		this.s = s;
		System.out.println("Inside the constructor: "+s);
	}

}
